# Creator-Profil

In etwa zehn Minuten fragt dich dein Chat nach deinen Preisen, deiner Nische und deinem Schreibstil. Daraus entsteht dein Profil. Alle drei Produkte der Werkstatt lesen es, wenn du einen Auftrag beginnst.

## Erfundenes Beispiel

Du drehst Küchenvideos und schreibst Marken mit „du“ an. Du gibst fünf deiner Nachrichten als Beispiele mit. Wenn du später eine Anfrage zu einem Schneebrett beantwortest, kennt der Chat deine Anrede und greift auf deine hinterlegten Preise zu.

## Im Download

Du bekommst den Fragenkatalog zum Einrichten, die gemeinsame Anweisung für dein Projekt und eine Anleitung. Am Ende des Gesprächs hast du deine persönliche Profildatei für die drei Produkte.

## So nutzt du es

Öffne ein Projekt in Claude oder ChatGPT und füge die gemeinsame Anweisung aus `vorlagen/projekt-anweisung.md` ein. Mit `vorlagen/einrichtungs-prompt.md` startest du das Gespräch. Für dein eigenes Profil nennst du deine Preise oder gibst deine Preisliste mit. Fehlende Angaben fragt der Chat nach. Möchtest du die Einrichtung ausprobieren, bitte ausdrücklich um einen Probelauf mit Beispielwerten. Für ein genaueres Bild von deinem Ton kannst du fünf bis zehn Nachrichten mitgeben.

Der Chat schreibt deine bestätigten Angaben in `profil.json`. Lege die Datei ins Projekt. Wenn du später etwas ändern möchtest, reicht ein Satz wie „Ändere mein Zahlungsziel auf 21 Tage“.

## Einbau

Öffne dein Büro-Projekt. Füge die gemeinsame Vorlage aus `vorlagen/projekt-anweisung.md` einmal als Projekt-Anweisung ein. Für ChatGPT lädst du aus diesem Download nur `werkstatt-creator-profil.txt` als Projektdatei hoch. Für Claude installierst du das beiliegende Skill-ZIP `creator-profil.zip`. Verwende dasselbe Profil und starte je Auftrag einen Chat.
